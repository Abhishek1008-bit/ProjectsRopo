package in.serosoft.boot.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import in.serosoft.boot.entity.Student;
import in.serosoft.boot.service.StudentService;

@RestController
@RequestMapping("students")
public class StudentController {
	
	@Autowired
	private StudentService studentService;
	
	
	@GetMapping(value="pages/{pageno}/{count}",produces="application/json")
	public Iterable<Student> showAllStudentPagewise(@PathVariable("pageno") int pageno, @PathVariable("count") int count) {
		return studentService.getAllPageWise(pageno,count);
	}
	
	@GetMapping(value="sorted/{field}",produces="application/json")
	public Iterable<Student> showAllStudentDetailsSorted(@PathVariable("field") String field) {
		return studentService.getAllSortedStudent(field);
	}
	
	@GetMapping(value="sem/{start}/{end}", produces="application/json")
	public List<Student> findBySemesterBetween(@PathVariable("start") int start, @PathVariable("end") int end){
		return studentService.findBySemesterBetween(start, end);
	}
	@GetMapping(value="{branch}/{sem}", produces="application/json")
	public List<Student> showStudentOnBranchAndSem(@PathVariable("branch") String branch, @PathVariable("sem") int sem){
		return studentService.getStudentByBranchAndSem(branch, sem);
	}
	@GetMapping(value="/branch/{branch}", produces="application/json")
	public List<Student> showStudentDetailsByBranch(@PathVariable("branch") String branch) {
		return studentService.getStudentByBranch(branch);
	}
	
	@GetMapping(value="{rno}", produces="application/json")
	public Student showStudentDetails(@PathVariable("rno") int rno) {
		return studentService.searchByRno(rno);
	}
	@GetMapping(produces="application/json")
	public Iterable<Student> showAllStudentDetails() {
		return studentService.getAllStudents();
	}
	@DeleteMapping(value="{rno}", produces="application/json")
	public Student deleteStudentDetails(@PathVariable("rno") int rno) {
		return studentService.deleteStudent(rno);
	}
	@PostMapping(produces="application/json", consumes="application/json")
	public Student saveStudent(@RequestBody Student student) {
		return studentService.saveStudent(student);
	}
}
