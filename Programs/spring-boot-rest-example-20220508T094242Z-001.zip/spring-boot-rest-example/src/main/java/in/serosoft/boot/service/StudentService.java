package in.serosoft.boot.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.stereotype.Service;

import in.serosoft.boot.dao.StudentRepository;
import in.serosoft.boot.entity.Student;

@Service
public class StudentService {

	@Autowired
	private StudentRepository studentRepository;
	
	public Iterable<Student> getAllPageWise(int pageno, int count){
		Pageable pageable=PageRequest.of(pageno, count, Sort.by("rno"));
		return studentRepository.findAll(pageable);
	}
	public Iterable<Student> getAllSortedStudent(String field){
		//Sort sort=Sort.by(field);
		Sort sort=Sort.by(Direction.ASC, field);
		return studentRepository.findAll(sort);
	}
	public List<Student> findBySemesterBetween(int start, int end){
		return studentRepository.findBySemesterBetween(start, end);
	}
	public List<Student> getStudentByBranchAndSem(String branch, int semester){
		return studentRepository.findByBranchAndSemester(branch, semester);
	}
	public List<Student> getStudentByBranch(String branch){
		return studentRepository.findByBranch(branch);
	}
	public Student saveStudent(Student student) {
		return studentRepository.save(student);
	}
	public Student searchByRno(int rno) {
		Optional<Student> optional=studentRepository.findById(rno);
		return optional.get();
	}
	public Student deleteStudent(int rno) {
		Student student=searchByRno(rno);
		studentRepository.deleteById(rno);	
		return student;
	}
	public Iterable<Student> getAllStudents() {
		return studentRepository.findAll();
	}
	
	
}
