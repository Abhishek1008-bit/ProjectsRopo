package in.serosoft.boot.dao;

import java.util.List;

import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.PagingAndSortingRepository;

import in.serosoft.boot.entity.Student;

//public interface StudentRepository extends CrudRepository<Student, Integer> {
public interface StudentRepository extends PagingAndSortingRepository<Student, Integer> {
	
	public List<Student> findByBranch(String branch);

	public List<Student> findByBranchAndSemester(String branch, int semester);

	public List<Student> findBySemesterBetween(int start, int end);

}
