package in.serosoft.training;



import org.hibernate.Session;
import org.hibernate.Transaction;

public class FacultyEntry {

	public static void main(String[] args) {
		
		
		Faculty f1=new Faculty(111,new Name("aa","bb","cc"),"MTech",5, new Address(555,"abroad","indore"));
		Faculty f2=new Faculty(112,new Name("dd","ee","ff"),"MTech",12,new Address(155,"newmarket","bhopal"));
		Faculty f3=new Faculty(113,new Name("gg","hh","ii"),"BTech",15,new Address(345,"andheri","mumbai"));
		Faculty f4=new Faculty(114,new Name("jj","kk","ll"),"BTech",5,new Address(510,"canatplace","delhi"));
		Faculty f5=new Faculty(115,new Name("mm","nn","oo"),"ME",9,new Address(65,"mgroad","ujjain"));
		
		//create session object
		Session session=Utililty.getSessionFactory().openSession();
		//begin transaction
		Transaction tr=session.beginTransaction();
		//save
		session.save(f1); session.save(f2); session.save(f3); session.save(f4); session.save(f5);
		//commit transaction
		tr.commit();
		//close the session
		session.close();
		
		System.out.println("Data Stored...!");
	}

}
