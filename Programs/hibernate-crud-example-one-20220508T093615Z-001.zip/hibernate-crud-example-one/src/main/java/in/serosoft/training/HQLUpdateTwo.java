package in.serosoft.training;

import java.util.Scanner;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

public class HQLUpdateTwo {

	public static void main(String[] args) {
		Session session=Utililty.getSessionFactory().openSession();
		String hql="update Employee set sal=sal+:amount where eno=:id";
		Query query=session.createQuery(hql);
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Eno : ");
		int eno=sc.nextInt();
		System.out.println("Enter Amount : ");
		int amt=sc.nextInt();
		
		query.setParameter("id", eno);
		query.setParameter("amount", amt);
		
		Transaction tr=session.beginTransaction();
		int n=query.executeUpdate();
		tr.commit();
		System.out.println(n+" rows modified..!");
		session.close();

	}

}
