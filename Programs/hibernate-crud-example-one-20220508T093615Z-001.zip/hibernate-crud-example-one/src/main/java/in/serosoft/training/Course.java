package in.serosoft.training;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;

import lombok.Data;

@Entity
@Data
public class Course {
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "sg")
	@SequenceGenerator(name = "sg", sequenceName = "course_seq", initialValue = 1001)
	private int code;
	private String name;
	private String dept;
	public Course(String name, String dept) {
		super();
		this.name = name;
		this.dept = dept;
	}
	
}
