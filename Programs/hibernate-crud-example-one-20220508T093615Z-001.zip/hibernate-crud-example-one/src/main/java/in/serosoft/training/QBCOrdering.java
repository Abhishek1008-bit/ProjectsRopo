package in.serosoft.training;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Order;

public class QBCOrdering {

	public static void main(String[] args) {

		Session session=Utililty.getSessionFactory().openSession();
		Criteria criteria=session.createCriteria(Faculty.class);
		
		Order ord1=Order.asc("experience");
		Order ord2=Order.asc("qualification");
		
		criteria.addOrder(ord1); criteria.addOrder(ord2);
		
		List<Faculty> faculties=criteria.list();
		for(Faculty faculty:faculties) {
			System.out.println(faculty.getName());
			System.out.println(faculty.getExperience());
			System.out.println(faculty.getQualification());
			System.out.println("_________________________________________________________");
		}
		session.close();

	}

}
