package in.serosoft.training;

import java.util.Scanner;

import org.hibernate.Session;

public class SearchFaculty {

	public static void main(String[] args) {

		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Faculty Code : ");
		int code=sc.nextInt();
		
		//Query By Id (we fetch the data by passing id) 
		
		//create session object
		Session session=Utililty.getSessionFactory().openSession();
		
		//call get/load method
		Faculty faculty=session.get(Faculty.class, code);
		
		//close session object
		
		System.out.println(faculty.getCode());
		System.out.println(faculty.getName().getFname());
		System.out.println(faculty.getName().getMname());
		System.out.println(faculty.getName().getLname());
		System.out.println(faculty.getQualification());
		System.out.println(faculty.getExperience());
		
		session.close();
	}

}
