package in.serosoft.training;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.Id;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
public class Faculty implements Serializable {

	@Id
	private int code;
	private Name name;
	private String qualification;
	private int experience;
	private Address address;
	
}
