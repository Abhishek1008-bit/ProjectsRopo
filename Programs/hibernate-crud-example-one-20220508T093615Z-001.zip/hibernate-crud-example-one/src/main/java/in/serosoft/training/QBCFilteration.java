package in.serosoft.training;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.Restrictions;

public class QBCFilteration {

	public static void main(String[] args) {
	
		Session session=Utililty.getSessionFactory().openSession();
		Criteria criteria=session.createCriteria(Faculty.class);
		
		//Criterion crt1=Restrictions.between("experience", 10, 12);
		//Criterion crt1=Restrictions.in("qualification", "BTech","ME");
		Criterion crt1=Restrictions.eq("name.fname", "mm");
		criteria.add(crt1);
		
		/*
		//filteration
		Criterion crt1=Restrictions.gt("experience", 5);
		//criteria.add(crt1);
		Criterion crt2=Restrictions.eq("qualification", "MTech");
		//criteria.add(crt2);
		Criterion crt3=Restrictions.or(crt1,crt2);
		criteria.add(crt3);
		*/
		
		List<Faculty> faculties=criteria.list();
		for(Faculty faculty:faculties) {
			System.out.println(faculty.getName());
			System.out.println(faculty.getExperience());
			System.out.println(faculty.getQualification());
			System.out.println("_________________________________________________________");
		}
		session.close();
	}

}
