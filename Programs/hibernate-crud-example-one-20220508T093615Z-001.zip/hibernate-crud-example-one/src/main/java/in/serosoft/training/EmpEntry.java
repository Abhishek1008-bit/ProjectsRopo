package in.serosoft.training;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class EmpEntry {

	public static void main(String[] args) {
	
		
		Employee e1=new Employee(); e1.setEno(111); e1.setEname("Manish"); e1.setSalary(50000); e1.setDesg("SE");
		Employee e2=new Employee(); e2.setEno(112); e2.setEname("Priya"); e2.setSalary(60000); e2.setDesg("SSE");
		Employee e3=new Employee(); e3.setEno(113); e3.setEname("Anup"); e3.setSalary(70000); e3.setDesg("TL");
		Employee e4=new Employee(); e4.setEno(114); e4.setEname("Deepak"); e4.setSalary(40000); e4.setDesg("SE");
		Employee e5=new Employee(); e5.setEno(115); e5.setEname("Gaurav"); e5.setSalary(660000); e5.setDesg("SSE");
		Employee e6=new Employee(); e6.setEno(116); e6.setEname("Riya"); e6.setSalary(30000); e6.setDesg("TL");

		//Configuration config=new Configuration().configure("abc.cfg.xml");
		//Configuration config=new Configuration().configure();
		//Session session=config.buildSessionFactory().openSession();
		/*
		SessionFactory sf=config.buildSessionFactory();
		Session session=sf.openSession();
		*/
		Session session=Utililty.getSessionFactory().openSession();
		Transaction tr=session.beginTransaction();
		session.save(e1);
		session.save(e2);
		session.save(e3);
		session.save(e4);
		session.save(e5);
		session.save(e6);
		tr.commit();
		
		session.close();
		System.out.println("Data Stored....!");
		
		
		
	}

}
