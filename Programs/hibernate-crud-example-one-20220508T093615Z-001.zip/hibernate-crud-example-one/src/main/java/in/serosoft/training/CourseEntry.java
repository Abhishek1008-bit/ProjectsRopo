package in.serosoft.training;

import org.hibernate.Session;
import org.hibernate.Transaction;

public class CourseEntry {

	public static void main(String[] args) {
		Session session=Utililty.getSessionFactory().openSession();
		Transaction tr=session.beginTransaction();
		session.save(new Course("java","cs"));
		session.save(new Course("laser","ec"));
		session.save(new Course("structure","civil"));
		session.save(new Course("mcdesign","mech"));
		tr.commit();
		
		session.close();
		System.out.println("Data Stored....!");

	}

}
