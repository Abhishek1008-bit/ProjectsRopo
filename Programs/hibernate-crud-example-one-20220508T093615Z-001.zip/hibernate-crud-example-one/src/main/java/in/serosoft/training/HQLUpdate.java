package in.serosoft.training;



import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

public class HQLUpdate {

	public static void main(String[] args) {
		Session session=Utililty.getSessionFactory().openSession();
		//String hql="update Employee set sal=sal+500";
		//Query query=session.createQuery(hql);
		Query query=session.getNamedQuery("incrementQuery");
		Transaction tr=session.beginTransaction();
		int n=query.executeUpdate();
		tr.commit();
		System.out.println(n+" rows modified..!");
		session.close();
	}

}
