package in.serosoft.training;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;

public class HQLExampleOne {

	public static void main(String[] args) {
		
		Session session=Utililty.getSessionFactory().openSession();
		//Query query=session.createQuery("from Employee where desg='TL' and sal>=50000");
		Query query=session.getNamedQuery("allEmployeeQuery");
		List<Employee> employees=query.list();
		for(Employee employee:employees) {
			System.out.println(employee);
		}
		session.close();
	}

}
