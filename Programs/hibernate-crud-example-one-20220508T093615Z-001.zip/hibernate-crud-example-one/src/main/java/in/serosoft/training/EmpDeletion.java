package in.serosoft.training;

import org.hibernate.Session;
import org.hibernate.Transaction;

public class EmpDeletion {

	public static void main(String[] args) {
		
		//create a session object
		Session session=Utililty.getSessionFactory().openSession();
		//begin the transaction
		Employee emp=new Employee(); emp.setEno(113);
		Transaction tr=session.beginTransaction();
		//call delete method
		session.delete(emp);
		//commit the transaction
		tr.commit();
		//close the session
		session.close();
		System.out.println("Deleted ....");
		
	}

}
