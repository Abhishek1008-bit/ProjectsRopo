package in.serosoft.training;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.Projection;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;

public class QBCProjectionExampleOne {

	public static void main(String[] args) {

		Session session=Utililty.getSessionFactory().openSession();
		Criteria criteria=session.createCriteria(Faculty.class);
		Criterion crt=Restrictions.gt("experience", 5);
		criteria.add(crt);
		Projection pr1=Projections.property("name.fname");
		criteria.setProjection(pr1);
		List<String> values=criteria.list();
		for(String value:values) {
			System.out.println(value);
		}
		
		/*
		Projection pr1=Projections.property("experience");
		criteria.setProjection(pr1);
		List<Integer> numbers=criteria.list();
			for(Integer number:numbers) {
			System.out.println(number);
		}
		*/
		session.close();

	}

}
