package in.serosoft.training;

import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class Utililty {
	public static SessionFactory getSessionFactory() {
		Configuration config=new Configuration().configure();
		SessionFactory sessionFactory=config.buildSessionFactory();
		return sessionFactory;
	}
}
