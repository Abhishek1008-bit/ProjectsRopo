package in.serosoft.training;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

@Entity
@Table(name = "employee")
@NamedQuery(name = "allEmployeeQuery",query="from Employee")
@NamedQuery(name = "incrementQuery", query="update Employee set sal=sal+500")
public class Employee {
	@Id
	@Column(name="eno")
	private int eno;
	@Column(name="ename", length = 20)
	private String ename;
	@Column(name = "sal")
	private int salary;
	private String desg;
	
	public String getDesg() {
		return desg;
	}
	public void setDesg(String desg) {
		this.desg = desg;
	}
	public int getEno() {
		return eno;
	}
	public void setEno(int eno) {
		this.eno = eno;
	}
	public String getEname() {
		return ename;
	}
	public void setEname(String ename) {
		this.ename = ename;
	}
	public int getSalary() {
		return salary;
	}
	public void setSalary(int salary) {
		this.salary = salary;
	}
	@Override
	public String toString() {
		return "Employee [eno=" + eno + ", ename=" + ename + ", salary=" + salary + ", desg=" + desg + "]";
	}
	
}
