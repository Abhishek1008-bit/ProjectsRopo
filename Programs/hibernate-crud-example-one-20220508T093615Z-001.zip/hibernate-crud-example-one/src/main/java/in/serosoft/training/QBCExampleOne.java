package in.serosoft.training;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;

public class QBCExampleOne {

	public static void main(String[] args) {
		//fetching employees data using Criteria interface
		
		
		//session object
		Session session=Utililty.getSessionFactory().openSession();
		//criteria
		Criteria criteria=session.createCriteria(Faculty.class);
		//list method call
		List<Faculty> faculties=criteria.list();
		
		//faculties.forEach((faculty)->System.out.println(faculty.getName()+","+faculty.getQualification()));
		
		for(Faculty faculty:faculties) {
			System.out.println(faculty);
		}
		
		
		
		//session close
		session.close();
	}

}
